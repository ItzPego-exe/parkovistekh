document.getElementById('mapa').onclick = function mapa() {
    window.location.href="mapBig.html"
}
document.getElementById('home').onclick = function mapa() {
    window.location.href="index.html"
}