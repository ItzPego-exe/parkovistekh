document.getElementById('home').onclick = function mapa() {
    window.location.href="index.html"
}
document.getElementById('places').onclick = function places() {
    window.location.href="places.html"
}