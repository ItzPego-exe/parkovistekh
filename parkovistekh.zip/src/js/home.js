
document.getElementById('home').onclick = function home() {
    window.location.href="index.html"
}
document.getElementById('mapa').onclick = function mapa() {
    window.location.href="mapBig.html"
}
document.getElementById('places').onclick = function places() {
    window.location.href="places.html"
}
/*if (navigator.geolocation) {
    navigator.geolocation.getCurrentPosition(logPosition);
  } else {
    console.log("Geolocation is not supported by this browser.");
  }
  
  function logPosition(position) {
    const latitude = position.coords.latitude;
    const longitude = position.coords.longitude;
    console.log("Current Position:", latitude, longitude);
}*/
const latitude = 49.949653636372176
const longitude =  15.268551806598209
let parkoviste = 
[
    {
        id:0,
        name: "Parkoviste 1",
        lat: 49.950383556266836, 
        lng: 15.266729421057978
    },
    {
        id:1,
        name: "Parkoviste 2",
        lat: 49.950124431308076,
        lng:  15.265981147631527
    },
    {
        id:2,
        name: "Parkoviste 3",
        lat: 49.95018642273082,
        lng:  15.272363783983822
    },
    {
        id:3,
        name: "Parkoviste 4",
        lat: 49.95282732524841,
        lng: 15.270913666226207
    },
    {
        id:4,
        name: "Parkoviste 5",
        lat: 49.95445643568166, 
        lng: 15.270956581567349
    },
    {
        id:5,
        name: "Parkoviste 6",
        lat: 49.94868310823556, 
        lng: 15.268148835449288
    },
    {
        id:6,
        name: "Parkoviste 7",
        lat: 49.95175042539201, 
        lng: 15.275269573980726
    },
    {
        id:7,
        name: "Parkoviste 8",
        lat: 49.94762208615694, 
        lng: 15.277694290755218
    },
    {
        id:8,
        name: "Parkoviste 9",
        lat: 49.94762208615694, 
        lng: 15.277694290755218
    },
    {
        id:9,
        name: "Parkoviste 10",
        lat: 49.94762208615694, 
        lng: 15.277694290755218
    }

]

  